﻿using System.Windows.Controls;

namespace ArdumotoBot.Remote
{
    /// <summary>
    /// Interaction logic for Controller.xaml
    /// </summary>
    public partial class ControllerInterface : UserControl
    {
        public ControllerInterface()
        {
            InitializeComponent();
        }
    }
}
