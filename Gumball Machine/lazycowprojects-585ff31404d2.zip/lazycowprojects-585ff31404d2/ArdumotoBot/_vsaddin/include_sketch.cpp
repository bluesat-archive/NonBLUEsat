extern "C" void __cxa_pure_virtual() {}

//full path includes for vs intellisense only! 
#include "include_libs.h"
//include wprogram.h and the current project sketch
#include "include_board.c"

void setup();
void loop();

