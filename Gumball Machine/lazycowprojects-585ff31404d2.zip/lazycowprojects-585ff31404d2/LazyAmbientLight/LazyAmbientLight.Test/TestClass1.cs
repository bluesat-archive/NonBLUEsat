
namespace LazyAmbientLight.Test
{
    
    public class TestClass1
    {

     
        public void FirstTest()
        {
            
        }

    }

}